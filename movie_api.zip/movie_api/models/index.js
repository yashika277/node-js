module.exports.userSchema = require("./user.model");
